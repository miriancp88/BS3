<?php
session_start();
include_once "conectar.php"; 
include_once "seguridad.php";

// Verificar si se recibió el ID del pedido y el método de pago
if (isset($_POST['idPedido'], $_POST['paymentMethod'])) {
    $idPedido = $_POST['idPedido'];
    $paymentMethod = $_POST['paymentMethod'];

    // Actualizar el estado del pedido a "pagado"
    $queryUpdatePedido = "UPDATE pedidos SET estadoPedido = 'pagado' WHERE idPedido = :idPedido";
    $stmtUpdatePedido = $con->prepare($queryUpdatePedido);
    $stmtUpdatePedido->bindParam(':idPedido', $idPedido);
    $stmtUpdatePedido->execute();

    // Destruir la sesión para eliminar el carrito
    unset($_SESSION['carrito']);  
} else {
    // Si no se recibió alguno de los datos necesarios, redirigir a la página de carrito
    header("Location: carrito.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pago Realizado</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            text-align: center;
            margin-top: 100px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Pago Realizado</h1>
        <p>El pago se ha realizado correctamente.</p>
        
        <a href="index.php">Volver al inicio</a>
    </div>
</body>
</html>

