<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/modificarUsuarioFormulario.css">
    <title>Agregar Nuevo Artículo</title>
</head>
<body>

<div class="container">
    <h2>Agregar Nuevo Artículo</h2>
    <form action="articuloInsertar.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>
        </div>
        <div class="form-group">
            <label for="descripcion">Descripción:</label>
            <textarea id="descripcion" name="descripcion" required></textarea>
        </div>
        <div class="form-group">
            <label for="codigoCategoria">Código de Categoría:</label>
            <input type="text" id="codigoCategoria" name="codigoCategoria" required>
        </div>
        <div class="form-group">
            <label for="precio">Precio:</label>
            <input type="number" id="precio" name="precio" step="0.01" required>
        </div>
        <div class="form-group">
            <label for="imagen">Imagen:</label>
            <input type="file" id="imagen" name="imagen" accept="image/*" required>
        </div>
        <div class="form-group">
            <label for="descuento">Descuento:</label>
            <input type="number" id="descuento" name="descuento" step="0.01">
        </div>
        <div class="form-group">
            <label for="estado">Estado:</label>
            <select id="estado" name="estado" required>
                <option value="1">Activo</option>
                <option value="0">Inactivo</option>                
            </select>
        </div>
        <button type="submit" class="btn">Agregar Artículo</button>
        <button onclick="window.location.href='panelAdministrador.php'" class="btn">Volver</button>
    </form>
</div>

</body>
</html>

