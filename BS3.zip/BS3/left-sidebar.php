<?php 
include('conectar.php'); 
function getCategorias() {
    global $con; 
    $categorias = [];
    try {
        $stmt = $con->prepare("SELECT * FROM categorias WHERE estado = 1 ORDER BY codigoCategoriaPadre, codigoCategoria");
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($result as $row) {
            $categorias[$row['codigoCategoriaPadre']][] = $row;
        }
        return $categorias;
    } catch (PDOException $e) {
        die('Error: ' . $e->getMessage());
    }
}

$categorias = getCategorias();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BS3</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<aside class="left-sidebar">
    <nav>
        <ul>
            <?php
            if (isset($categorias[0])) { // Categorías principales
                foreach ($categorias[0] as $categoria) {
                    echo '<li><a href="mostrarProductos.php?cat=' . $categoria['codigoCategoria'] . '">' . $categoria['nombre'] . '</a>';

                    if (isset($categorias[$categoria['codigoCategoria']])) { // Subcategorías
                        echo '<ul>';
                        foreach ($categorias[$categoria['codigoCategoria']] as $subcategoria) {
                            echo '<li><a href="mostrarProductos.php?cat=' . $subcategoria['codigoCategoria'] . '">' . $subcategoria['nombre'] . '</a></li>';
                        }
                        echo '</ul>';
                    }
                    echo '</li>';
                }
            }
            ?>
             <li><a href="articulosDescuento.php">OUTLET</a></li>
            <li><a href="articulosSoldOut.php">SOLD OUT</a></li>
        </ul>
    </nav>
</aside>
</body>
</html>
