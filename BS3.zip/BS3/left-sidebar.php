<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BS3</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<aside class="left-sidebar">
    <nav>
        <ul>            
            <li>
                <a href="gafas.php" id="gafas">GAFAS</a>
                <ul>
                    <li><a href="gafas.php">TODAS</a></li>
                    <li><a href="gafasPasta.php">GAFAS DE PASTA</a></li>
                    <li><a href="gafasMetal.php">GAFAS DE METAL</a></li>
                    <li><a href="gafasDescuento.php">OUTLET</a></li>
                    <li><a href="gafasSoldOut.php">SOLD OUT</a></li>
                </ul>
            </li>
           
        </ul>
    </nav>
</aside>
