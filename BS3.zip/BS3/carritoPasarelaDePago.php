
<?php

include("conectar.php");

include("seguridad.php");



// Verificar si se recibió el ID del pedido
if (isset($_GET['idPedido'])) {
    $idPedido = $_GET['idPedido'];
} else {
    // Si no se recibió el ID del pedido, redirigir a la página de carrito
    header("Location: carrito.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pasarela de Pago</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 500px;
        }
        .button {
            margin: 10px;
            padding: 20px;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>ELIJA SU METODO DE PAGO</h1>
    <div class="container">
        <form action="carritoPagoRealizado.php" method="post">
            
            <button type="submit" name="paymentMethod" value="tarjeta" class="button">
                <img src="imagenes/tarjeta.jpg" alt="Pagar con tarjeta" width="500">
            </button>
            >
            <button type="submit" name="paymentMethod" value="paypal" class="button">
                <img src="imagenes/paypal.jpg" alt="Pagar con PayPal" width="500">
            </button>
            <!-- Campo oculto para enviar el ID del pedido -->
            <input type="hidden" name="idPedido" value="<?php echo $idPedido; ?>">
        </form>
    </div>
</body>
</html>
