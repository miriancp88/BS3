


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BS3</title>
    <link rel="stylesheet" href="css/footer.css">
</head>
<body>

<footer>
<p>&copy; 2024 BS3. Todos los derechos reservados.</p>
</footer>
