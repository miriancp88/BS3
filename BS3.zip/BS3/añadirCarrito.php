<?php
session_start(); // Iniciar sesión si aún no está iniciada

// Incluir el archivo de conexión a la base de datos
include "conectar.php";

// Obtener el ID del producto
$idProducto = $_GET['id'];

// Verificar si el producto ya está en el carrito
$sql = "SELECT * FROM lineapedido WHERE numPedido = ? AND codArticulo = ?";
$stmt = $con->prepare($sql);
$numPedido = 1; 
$stmt->execute([$numPedido, $idProducto]);
$resultado = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$resultado) {
    // El producto no está en el carrito, agregarlo
    $sql = "INSERT INTO lineapedido (numPedido, codArticulo, cantidad, precio, descuento) VALUES (?, ?, 1, ?, ?)";
    $stmt = $con->prepare($sql);
    $precio = $_GET['precio']; // Suponiendo que el precio proviene del producto en la página web
    $descuento = 0; // Suponiendo que no hay descuento inicialmente
    $stmt->execute([$numPedido, $idProducto, $precio, $descuento]);
} else {
    // El producto ya está en el carrito, actualizar la cantidad
    $sql = "UPDATE lineapedido SET cantidad = cantidad + 1 WHERE numPedido = ? AND codArticulo = ?";
    $stmt = $con->prepare($sql);
    $stmt->execute([$numPedido, $idProducto]);
}



// Redirigir al usuario a la página del carrito
header('Location: carrito.php');
?>
