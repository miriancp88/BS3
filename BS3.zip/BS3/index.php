<?php
include('conectar.php'); 
include('header.php'); 

function getAllProductosAleatorios() {
    global $con;
    $productos = [];
    try {
        // Consulta para obtener todos los productos de todas las categorías y subcategorías de forma aleatoria
        $stmt = $con->prepare("
            SELECT articulos.* FROM articulos
            INNER JOIN categorias ON articulos.codigoCategoria = categorias.codigoCategoria
            WHERE articulos.estado = 1
            ORDER BY RAND()
        ");
        $stmt->execute();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $precio = $row['precio'];
            $descuento = $row['descuento'];
            if ($descuento > 0) {
                $nuevo_precio = $precio - ($precio * $descuento / 100);
                $precio = $nuevo_precio < 0 ? 0 : $nuevo_precio;
            }
            $producto = array(
                'nombre' => $row['nombre'],
                'descripcion' => $row['descripcion'],
                'imagen' => $row['imagen'],
                'precio' => $precio,
                'precioOriginal' => $row['precio'],
                'descuento' => $descuento,
                'codigoArticulo' => $row['codigoArticulo']
            );
            $productos[] = $producto;
        }
        return $productos;
    } catch (PDOException $e) {
        die('Error: ' . $e->getMessage());
    }
}

$productos = getAllProductosAleatorios();
?>
<div class="container">
<?php foreach ($productos as $producto): ?>
    <div class="card">
        <img src="uploads/<?php echo $producto['imagen']; ?>" alt="<?php echo $producto['nombre']; ?>" style="width: 450px;">
        <div class="card-body">
            <h3 class="card-title"><?php echo $producto['nombre']; ?></h3>
            <p class="card-description"><?php echo $producto['descripcion']; ?></p>
            <?php if ($producto['descuento'] > 0): ?>
                <p class="card-price"><?php echo number_format($producto['precio'], 2); ?>€ <span style="text-decoration: line-through; color: red;"><?php echo number_format($producto['precioOriginal'], 2); ?>€</span></p>
            <?php else: ?>
                <p class="card-price"><?php echo number_format($producto['precio'], 2); ?>€</p>
            <?php endif; ?>
            <form action="carrito.php" method="post">
                <input type="hidden" name="codigoArticulo" value="<?php echo $producto['codigoArticulo']; ?>">
                <button type="submit" class="add-to-cart-btn">Añadir al carrito</button>
            </form>
        </div>
    </div>
<?php endforeach; ?>
</div>
<?php
include 'left-sidebar.php';   
include 'right-sidebar.php';
include('footer.php'); 
?>
