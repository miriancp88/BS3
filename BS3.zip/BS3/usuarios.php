<?php
include("conectar.php");

include("seguridad.php");


// Función para obtener usuarios según los parámetros de búsqueda y ordenamiento
function obtenerUsuarios($con, $buscar = null, $ordenar = null) {
    try {
        $query = "SELECT dni, password, nombre, direccion, email, rol, estado FROM usuarios WHERE estado = 1";

        // Verificar si se ha enviado un nombre para buscar
        if (!empty($buscar)) {
            $nombre = "%$buscar%";
            $query .= " AND nombre LIKE :nombre";
        }

        // Verificar si se ha enviado un parámetro para ordenar
        if (!empty($ordenar)) {
            $query .= " ORDER BY $ordenar";
        }

        $statement = $con->prepare($query);

        // Vincular valores si es necesario
        if (!empty($nombre)) {
            $statement->bindParam(':nombre', $nombre, PDO::PARAM_STR);
        }

        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
        return array(); // Devolver un array vacío en caso de error
    }
}


function generarTablaUsuarios($usuarios) {
    ?>
    <table>
        <thead>
            <tr>
                <th>DNI</th>
                <th>Nombre</th>
                <th>Dirección</th>
                <th>Email</th>
                <th>Rol</th>            
                <th>Estado</th>
                <th>Modificar</th>
                <th>Eliminar</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($usuarios as $usuario): ?>
            <tr>
                <td><?php echo $usuario['dni']; ?></td>
                <td><?php echo $usuario['nombre']; ?></td>
                <td><?php echo $usuario['direccion']; ?></td>
                <td><?php echo $usuario['email']; ?></td>
                <td><?php echo $usuario['rol']; ?></td>
                <td><?php echo $usuario['estado']; ?></td>
                <td>
                    <a href="usuarioModificarFormulario.php?dni=<?php echo $usuario['dni']; ?>&nombre=<?php echo $usuario['nombre']; ?>&direccion=<?php echo $usuario['direccion']; ?>&email=<?php echo $usuario['email']; ?>&rol=<?php echo $usuario['rol']; ?>&estado=<?php echo $usuario['estado']; ?>" class="btn">Modificar</a>
                </td>
                <td>
                    <form action="confirmacion.php" method="POST" onsubmit="return confirmarEliminar();">
                        <input type="hidden" name="dni" value="<?php echo $usuario['dni']; ?>">
                        <button type="submit" class="btn btn-danger">Eliminar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php
}

// Obtener usuarios según los parámetros de búsqueda y ordenamiento
$buscar = isset($_GET['buscar']) ? $_GET['buscar'] : null;
$ordenar = isset($_GET['ordenar']) ? $_GET['ordenar'] : null;
$usuarios = obtenerUsuarios($con, $buscar, $ordenar);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de Usuarios</title>
    <link rel="stylesheet" href="css/tablaUsuarios.css"> 
</head>
<body>

<h2>Tabla de Usuarios</h2>

<div class="table-container">
    <a href="usuarioNuevoFormulario.php" class="btn">Agregar Nuevo Usuario</a> 
</div>

<form action="usuarios.php" method="GET">
    <div class="search-container">
        <input type="text" name="buscar" placeholder="Buscar por nombre">
        <button type="submit" class="btn">Buscar</button>
    </div>
    <br>
    <div class="order-container">
        <label for="ordenar">Ordenar por:</label>
        <select name="ordenar" id="ordenar">
            <option value="rol">Rol</option>
            <option value="nombre">Nombre</option>
        </select>
        <button type="submit" class="btn">Ordenar</button>
    </div>
</form>

<div class="table-container">
    <?php generarTablaUsuarios($usuarios); ?>
</div>

<button onclick="window.location.href='panelAdministrador.php'" class="btn">Volver</button>
<br>
<br>
<button onclick="window.location.href='usuarioBaja.php'" class="btn">Usuarios dados de Baja</button>

</body>
</html>
