<?php
include 'conectar.php';

include("seguridad.php");


function obtenerUsuariosDadoDeBaja($con, $nombre = null, $ordenarPor = null) {
    $query = "SELECT dni, password, nombre, direccion, email, rol, estado FROM usuarios WHERE estado = 0";

    // Verificar si se ha enviado un nombre para buscar
    if(isset($nombre)) {
        $query .= " AND nombre LIKE :nombre";
    }

    // Verificar si se ha enviado un parámetro para ordenar
    if(isset($ordenarPor)) {
        $query .= " ORDER BY $ordenarPor";
    }

    try {
        // Preparar y ejecutar la consulta SQL
        $statement = $con->prepare($query);

        // Vincular valores si es necesario
        if(isset($nombre)) {
            $nombre = "%$nombre%";
            $statement->bindParam(':nombre', $nombre, PDO::PARAM_STR);
        }

        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
        return array();
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de Usuarios</title>
    <link rel="stylesheet" href="css/tablaUsuarios.css"> 
</head>
<body>

<h2>Tabla de Usuarios</h2>

<form action="usuarios.php" method="GET">
    <div class="search-container">
        <input type="text" name="buscar" placeholder="Buscar por nombre">
        <button type="submit" class="btn">Buscar</button>
    </div>
    <br>
    <div class="order-container">
        <label for="ordenar">Ordenar por:</label>
        <select name="ordenar" id="ordenar">
            <option value="rol">Rol</option>
            <option value="nombre">Nombre</option>
        </select>
        <button type="submit" class="btn">Ordenar</button>
    </div>
</form>

<table>
    <thead>
        <tr>
            <th>DNI</th>
            <th>Nombre</th>
            <th>Dirección</th>
            <th>Email</th>
            <th>Rol</th>            
            <th>Estado</th>
            <th>Modificar</th>
            
        </tr>
    </thead>
    <tbody>
    <?php
    
    $usuarios = obtenerUsuariosDadoDeBaja($con, isset($_GET['buscar']) ? $_GET['buscar'] : null, isset($_GET['ordenar']) ? $_GET['ordenar'] : null);

    foreach ($usuarios as $usuario): ?>
        <tr>
            <td><?php echo $usuario['dni']; ?></td>
            <td><?php echo $usuario['nombre']; ?></td>
            <td><?php echo $usuario['direccion']; ?></td>
            <td><?php echo $usuario['email']; ?></td>
            <td><?php echo $usuario['rol']; ?></td>
            <td><?php echo $usuario['estado']; ?></td>
            <td>
                <a href="usuarioModificarFormulario.php?dni=<?php echo $usuario['dni']; ?>&nombre=<?php echo $usuario['nombre']; ?>&direccion=<?php echo $usuario['direccion']; ?>&email=<?php echo $usuario['email']; ?>&rol=<?php echo $usuario['rol']; ?>&estado=<?php echo $usuario['estado']; ?>" class="btn">Modificar</a>
            </td>
        <br>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<button onclick="window.location.href='panelAdministrador.php'" class="btn">Volver</button>
<br>
<br>

</body>
</html>
