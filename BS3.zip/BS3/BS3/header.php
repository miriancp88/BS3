<?php
    // Si la sesión aún no se ha iniciado, la iniciamos
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    include_once "conectar.php"; // Incluir archivo de conexión a la base de datos

    if (isset($_SESSION['autentificado']) && $_SESSION['autentificado'] == "OK") {
        // Si el usuario está autenticado, obtén su nombre y rol de la base de datos
        $email = $_SESSION['usuario'];
        $stmt = $con->prepare("SELECT nombre, rol FROM usuarios WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $nombreUsuario = $result['nombre']; // Nombre del usuario
        $rolUsuario = $result['rol']; // Rol del usuario
    }
?>



<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tu Sitio Web</title>
    <link rel="stylesheet" href="css/headerStyles.css">
    <link rel="stylesheet" href="css/loginStyles.css">   
    <link rel="stylesheet" href="css/articulos.css">
    <link rel="stylesheet" href="css/carrito.css">
    
    

    



   
</head>
<body>
    <header class="mi-header">
            <div class="logo-container">
            <img src="Imagenes/logo.png" alt="Logo">
        </div>
        <nav>
            <ul>
            <li><a href="index.php">HOME</a></li>
                <li><a href="sobreNosotros.php">QUIEN SOMOS</a></li>
                <li><a href="contacto.php">CONTACTO</a></li>
            </ul>
        </nav>
        <div class="user-cart"> 
            <?php
                if (isset($nombreUsuario)) {
                    echo '<span>Hola ' . $nombreUsuario . '</span>'; // Mostrar nombre del usuario
                    
                    // Mostrar botones según el rol del usuario
                    if ($rolUsuario == "cliente") {
                       
                   
                    }
                    
                    echo '<a href="cerrarSesion.php"><button>Cerrar Sesión</button></a>'; 

                } else {
                    echo '<a href="login.php"><button>INICIAR SESION</button></a>'; // 
                    
                }
            ?>
            <a href="carrito.php"><button>Carrito</button></a>
        </div>
    </header>
</body>
</html>

