<?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="es">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BS3</title>
    <link rel="stylesheet" href="css/articulos.css">
    
</head>

<?php
// Función para calcular el precio con descuento
function calcularPrecioConDescuento($precio, $descuento) {
    $nuevo_precio = $precio - $descuento;
    return $nuevo_precio < 0 ? 0 : $nuevo_precio;
}

?>

<div class="container">
    <?php
    // Verificar si las constantes no están definidas
    if (!defined('USER_DB') && !defined('PASSWORD')) {
        include 'conectar.php';
    }
    try {
        $query = "SELECT articulos.* 
                  FROM articulos 
                  INNER JOIN categorias ON articulos.codigoCategoria = categorias.codigoCategoria 
                  WHERE categorias.codigoCategoriaPadre = 1 
                  AND articulos.descuento IS NOT NULL AND articulos.descuento <> 0"; // Modificación aquí
        $stmt = $con->query($query);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            // Calcular el nuevo precio con la función calcularPrecioConDescuento
            $precio = $row['precio'];
            $descuento = $row['descuento'];
            $nuevo_precio = calcularPrecioConDescuento($precio, $descuento);
            ?>
            <div class="card">
                <img src="uploads/<?php echo $row['imagen']; ?>" alt="Imagen del artículo" style="width: 500px;">
                <div class="card-body">
                    <h3 class="card-title"><?php echo $row['nombre']; ?></h3>
                    <p class="card-description"><?php echo $row['descripcion']; ?></p>
                    <p class="card-price"><?php echo $nuevo_precio; ?>€ <span style="text-decoration: line-through; color: red;"><?php echo $precio; ?>€</span></p>
                    <form action="carrito.php" method="post">
                        <input type="hidden" name="codigoArticulo" value="<?php echo $row['codigoArticulo']; ?>">
                        <button type="submit" class="add-to-cart-btn">Añadir al carrito</button>
                    </form>
                </div>
            </div>
            <?php
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    ?>
</div>

<?php include_once "left-sidebar.php"; ?> 
<?php include_once "right-sidebar.php"; ?> 
<?php include_once "footer.php"; ?> 
</body>
</html>
