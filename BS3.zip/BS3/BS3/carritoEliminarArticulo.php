<?php
session_start();

if (isset($_GET['index'])) {
    $index = $_GET['index'];

    if (isset($_SESSION['carrito'])) {
        $carrito = $_SESSION['carrito'];
        if (isset($carrito[$index])) {
            unset($carrito[$index]);
            $_SESSION['carrito'] = $carrito;
            header("Location: carrito.php");
            exit();
        } else {
            echo 'El índice del artículo no es válido.';
        }
    } else {
        echo 'No hay artículos en el carrito.';
    }
} else {
    echo 'Índice de artículo no proporcionado.';
}
?>
