<?php
// Si la sesión aún no se ha iniciado, la iniciamos
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include_once "conectar.php"; // Incluir archivo de conexión a la base de datos

if (isset($_SESSION['autentificado']) && $_SESSION['autentificado'] == "OK") {
    // Si el usuario está autenticado, obtén su dni de la base de datos
    $email = $_SESSION['usuario'];
    $stmt = $con->prepare("SELECT dni FROM usuarios WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $dniUsuario = $result['dni']; // dni del usuario


    try {
        // Preparar la consulta SQL para obtener los datos de los pedidos del usuario
        $query = "SELECT * FROM pedidos WHERE codUsuario = :dni";
        $statement = $con->prepare($query);
        $statement->bindParam(':dni', $dniUsuario, PDO::PARAM_STR); // Utiliza $dniUsuario en lugar de $dni
        $statement->execute();
        $pedidos = $statement->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }
} else {
    // Si el usuario no está autenticado, redirigirlo a la página de inicio de sesión
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedidos del Usuario</title>
    <link rel="stylesheet" href="css/tablaUsuarios.css"> 
</head>
<body>

<h2>Pedidos del Usuario</h2>

<table>
    <thead>
        <tr>
            <th>ID Pedido</th>
            <th>Fecha</th>
            <th>Total</th>
            <th>Estado del Pedido</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($pedidos as $pedido): ?>
        <tr>
            <td><?php echo $pedido['idPedido']; ?></td>
            <td><?php echo $pedido['fecha']; ?></td>
            <td><?php echo $pedido['total']; ?></td>
            <td><?php echo $pedido['estadoPedido']; ?></td>
            <td><?php if ($pedido['estadoPedido'] == 'pagado' || $pedido['estadoPedido'] == 'pendiente'): ?>
                    <form action="cientePedidoCancelar.php" method="post"> 
                        <input type="hidden" name="idPedido" value="<?php echo $pedido['idPedido']; ?>">
                        <button type="submit" class="cancelar-btn">Cancelar</button>
                    </form>
                    <?php endif; ?>
                </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<button onclick="window.location.href='index.php'" class="btn">Volver</button>

</body>
</html>

