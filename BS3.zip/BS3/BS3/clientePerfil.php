<?php
// Si la sesión aún no se ha iniciado, la iniciamos
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include_once "conectar.php";


try {
    if (isset($_SESSION['autentificado']) && $_SESSION['autentificado'] == "OK") {
        // Si el usuario está autenticado, obtén su DNI de la base de datos
        $email = $_SESSION['usuario'];
        $stmt = $con->prepare("SELECT dni, nombre, direccion, email, rol, estado FROM usuarios WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verificar si se encontró el usuario en la base de datos
        if (!$usuario) {
            throw new Exception("El usuario no existe en la base de datos.");
        }
    } else {
        // Si el usuario no está autenticado, redirigir a la página de inicio de sesión
        header("Location: login.php");
        exit;
    }
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de Usuario</title>
    <link rel="stylesheet" href="css/modificarUsuarioFormulario.css"> 
    <link rel="stylesheet" href="css/estilos.css"> 
</head>
<body>

<h2>Perfil de Usuario</h2>

<div class="table-container">
    <form action="index.php" method="get">
        <button type="submit" class="btn">Volver</button>
    </form>
    <br>
</div>

<form action="clienteGuardarPerfil.php" method="POST">
    <div class="form-group">
        <label for="dni">DNI:</label>
        <input type="text" id="dni" name="dni" value="<?php echo $usuario['dni']; ?>" readonly>
    </div>
    <div class="form-group">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="<?php echo $usuario['nombre']; ?>" required>
    </div>
    <div class="form-group">
        <label for="direccion">Dirección:</label>
        <input type="text" id="direccion" name="direccion" value="<?php echo $usuario['direccion']; ?>" required>
    </div>
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo $usuario['email']; ?>" required>
    </div>

    <button type="submit" class="btn">Actualizar Perfil</button>
</form>



</body>
</html>

