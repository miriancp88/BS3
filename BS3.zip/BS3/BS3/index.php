<?php
include 'header.php';


function obtenerArticulos($con) {
    try {
        $query = "SELECT articulos.* FROM articulos INNER JOIN categorias ON articulos.codigoCategoria = categorias.codigoCategoria WHERE categorias.codigoCategoriaPadre IN (1, 4) ORDER BY RAND() LIMIT 20";
        $stmt = $con->query($query);
        $articulos = array();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            // Calcular el nuevo precio si hay descuento
            $precio = $row['precio'];
            if (!empty($row['descuento'])) {
                $nuevo_precio = $precio - $row['descuento'];
                $precio = $nuevo_precio < 0 ? 0 : $nuevo_precio;
            }
            $articulo = array(
                'nombre' => $row['nombre'],
                'descripcion' => $row['descripcion'],
                'imagen' => $row['imagen'],
                'precio' => $precio,
                'codigoArticulo' => $row['codigoArticulo']
            );
            $articulos[] = $articulo;
        }
        return $articulos;
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BS3</title>
</head>
<body>
    
    <div class="container">
        <?php
        // Obtener los artículos
        $articulos = obtenerArticulos($con);
        foreach ($articulos as $articulo) {
        ?>
        <div class="card">
            <img src="uploads/<?php echo $articulo['imagen']; ?>" alt="Imagen del artículo" style="width: 450px;">
            <div class="card-body">
                <h3 class="card-title"><?php echo $articulo['nombre']; ?></h3>
                <p class="card-description"><?php echo $articulo['descripcion']; ?></p>
                <?php if (!empty($articulo['descuento'])): ?>
                    <p class="card-price"><?php echo $articulo['precio']; ?>€ <span style="text-decoration: line-through; color: red;"><?php echo $articulo['precio']; ?>€</span></p>
                <?php else: ?>
                    <p class="card-price"><?php echo $articulo['precio']; ?>€</p>
                <?php endif; ?>
                <form action="carrito.php" method="post">
                    <input type="hidden" name="codigoArticulo" value="<?php echo $articulo['codigoArticulo']; ?>">
                    <button type="submit" class="add-to-cart-btn">Añadir al carrito</button>
                </form>
            </div>
        </div>
        <?php
        }
        ?>
    </div>
    <?php include 'left-sidebar.php'; ?>
    <?php include 'right-sidebar.php'; ?>
    <?php include 'footer.php'; ?>
</body>
</html>
