
<?php
session_start();

include_once "conectar.php"; // Incluir archivo de conexión a la base de datos

// Función para verificar si el usuario está autenticado
function usuarioAutenticado() {
    return isset($_SESSION['autentificado']) && $_SESSION['autentificado'] == "OK";
}

// Función para redirigir según el estado de autenticación del usuario
function redirigirSegunAutenticacion() {
    if (usuarioAutenticado()) {
        // El usuario está autenticado, redirigir a la pasarela de pago
        header("Location: carritoInsertarPedido.php");
        exit; // Es importante salir del script después de redirigir
    } else {
        // El usuario no está autenticado, redirigir a la página de login
        header("Location: login.php");
        exit; // Es importante salir del script después de redirigir
    }
}

// Llamar a la función de redirección
redirigirSegunAutenticacion();
?>

