<?php
include("conectar.php");

// Recibir los datos del formulario
$nombre = $_POST['nombre'];
$descripcion = $_POST['descripcion'];
$codigoCategoria = $_POST['codigoCategoria'];
$precio = $_POST['precio'];
$imagen = $_FILES['imagen']['name']; // Nombre del archivo de imagen
$descuento = $_POST['descuento'];
$estado = $_POST['estado'];

// Ruta donde se guardará la imagen
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["imagen"]["name"]);

try {
    // Preparar la consulta SQL
    $stmt = $con->prepare("INSERT INTO articulos (nombre, descripcion, codigoCategoria, precio, imagen, descuento, estado) VALUES (:nombre, :descripcion, :codigoCategoria, :precio, :imagen, :descuento, :estado)");

    // Bind de parámetros
    $stmt->bindParam(':nombre', $nombre);
    $stmt->bindParam(':descripcion', $descripcion);
    $stmt->bindParam(':codigoCategoria', $codigoCategoria);
    $stmt->bindParam(':precio', $precio);
    $stmt->bindParam(':imagen', $imagen);
    $stmt->bindParam(':descuento', $descuento);
    $stmt->bindParam(':estado', $estado);

    // Subir la imagen al servidor
    if (move_uploaded_file($_FILES["imagen"]["tmp_name"], $target_file)) {
        // La imagen se ha subido correctamente, procedemos con la inserción en la base de datos
        // Ejecutar la consulta
        if ($stmt->execute()) {
            echo "¡Registro creado satisfactoriamente!";
            // Redirigir al usuario a la página de administrador
            header("Location: panelAdministrador.php");
            exit(); // Finalizar la ejecución del script
        } else {
            echo "Error al crear el registro.";
        }
    } else {
        echo "Error al subir la imagen.";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
