<?php
include("conectar.php");

function actualizarUsuario($con, $nombre, $email, $direccion, $dni) {
    try {
        $sql = "UPDATE usuarios SET nombre=:nombre, email=:email, direccion=:direccion WHERE dni=:dni";
        $statement = $con->prepare($sql);
        $statement->bindParam(':nombre', $nombre);
        $statement->bindParam(':email', $email);
        $statement->bindParam(':direccion', $direccion);
        $statement->bindParam(':dni', $dni);
        return $statement->execute();
    } catch (PDOException $e) {
        throw new Exception("Error al actualizar el usuario: " . $e->getMessage());
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los datos del formulario
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $direccion = $_POST['direccion'];
    $rol = $_POST['rol']; // Aunque no lo actualizamos, es mejor asegurarse de que se recibe
    $estado = $_POST['estado']; // Lo mismo para el estado
    $dni = $_POST['dni'];

    try {
        if (actualizarUsuario($con, $nombre, $email, $direccion, $dni)) {
            echo "Los cambios se han guardado correctamente.";
            header("Location: index.php");
            exit; // Importante: asegúrate de salir del script después de redirigir
        } else {
            throw new Exception("Ha ocurrido un error al intentar guardar los cambios.");
        }
    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage();
    }
} else {
    echo "No se han recibido datos del formulario.";
}
?>

