<?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="es">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BS3</title>
    <link rel="stylesheet" href="css/articulos.css">
    <link rel="stylesheet" href="css/soldOut.css">
</head>

<body>
<div class="container">
    <?php
    // Verificar si las constantes no están definidas
    if (!defined('USER_DB') && !defined('PASSWORD')) {
        include 'conectar.php';
    }
    try {
        $query = "SELECT articulos.* 
                  FROM articulos 
                  INNER JOIN categorias ON articulos.codigoCategoria = categorias.codigoCategoria 
                  WHERE categorias.codigoCategoriaPadre = 1 
                  AND articulos.estado = 0"; // Modificación aquí
        $stmt = $con->prepare($query);
        $stmt->execute();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            // Calcular el nuevo precio si hay descuento
            $precio = $row['precio'];
            if (!empty($row['descuento'])) {
                $nuevo_precio = $precio - $row['descuento'];
                $precio = $nuevo_precio < 0 ? 0 : $nuevo_precio;
            }
            ?>
            <div class="card" style="position: relative;">
                <?php if ($row['estado'] == 0): ?>
                    <div class="sold-out-overlay">SOLD OUT</div>
                <?php endif; ?>
                <img src="uploads/<?php echo $row['imagen']; ?>" alt="Imagen del artículo" style="width: 470px;">
                <div class="card-body">
                    <h3 class="card-title"><?php echo $row['nombre']; ?></h3>
                    <p class="card-description"><?php echo $row['descripcion']; ?></p>
                    <?php if (!empty($row['descuento'])): ?>
                        <p class="card-price"><?php echo $precio; ?>€ <span style="text-decoration: line-through; color: red;"><?php echo $row['precio']; ?>€</span></p>
                    <?php else: ?>
                        <p class="card-price"><?php echo $precio; ?>€</p>
                    <?php endif; ?>
                </div>
            </div>
            <?php
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    ?>
</div>

<?php include 'left-sidebar.php'; ?>
    <?php include 'right-sidebar.php'; ?>
    <?php include 'footer.php'; ?>
</body>
</html>

