<?php
session_start();
include_once "conectar.php"; // Incluir archivo de conexión a la base de datos

// Función para obtener el DNI del usuario autenticado
function obtenerDNIDeUsuarioAutenticado($con, $email) {
    $stmt = $con->prepare("SELECT dni FROM usuarios WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['dni'];
}

// Función para insertar un nuevo pedido
function insertarNuevoPedido($con, $totalCarrito, $dniUsuario) {
    $stmt = $con->prepare("INSERT INTO pedidos (fecha, total, estadoPedido, codUsuario, estado) VALUES (CURDATE(), :total, 'pendiente', :dni, 1)");
    $stmt->bindParam(':total', $totalCarrito);
    $stmt->bindParam(':dni', $dniUsuario);
    $stmt->execute();
    return $con->lastInsertId(); // Retorna el ID del pedido recién creado
}

// Función para insertar una línea de pedido
function insertarLineaDePedido($con, $idPedido, $codArticulo, $precio, $descuento) {
    $stmt = $con->prepare("INSERT INTO lineapedido (numPedido, codArticulo, cantidad, precio, descuento) VALUES (:numPedido, :codigoArticulo, 1, :precio, :descuento)");
    $stmt->bindParam(':numPedido', $idPedido);
    $stmt->bindParam(':codigoArticulo', $codArticulo);
    $stmt->bindParam(':precio', $precio);
    $stmt->bindParam(':descuento', $descuento);
    $stmt->execute();
}

if ($_SESSION['autentificado'] == "OK" && isset($_SESSION['usuario'])) {
    $email = $_SESSION['usuario'];
    $dniUsuario = obtenerDNIDeUsuarioAutenticado($con, $email);

    if (isset($_SESSION['totalCarrito'])) {
        $totalCarrito = $_SESSION['totalCarrito'];
        $idPedido = insertarNuevoPedido($con, $totalCarrito, $dniUsuario);

        if (isset($_COOKIE['carrito']) && !empty($_COOKIE['carrito'])) {
            $carrito = json_decode($_COOKIE['carrito'], true);
            foreach ($carrito as $item) {
                insertarLineaDePedido($con, $idPedido, $item['codigoArticulo'], $item['precio'], $item['descuento']);
            }
        }

        // Redirigir a la pasarela de pago con el ID del pedido
        header("Location: carritoPasarelaDePago.php?idPedido=$idPedido");
        exit;
    } else {
        echo "Error: No se recibió el total del carrito.";
        exit;
    }
} else {
    // El usuario no está autenticado, redirigir a la página de carrito
    header("Location: carrito.php");
    exit;
}
?>
