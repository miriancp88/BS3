<?php
include("conectar.php");

// Esta función inserta una nueva categoría en la base de datos
function insertarCategoria($con, $nombre, $estado, $codigoCategoriaPadre) {
    // Verificar si el nombre de la categoría ya existe en la base de datos
    $stmt = $con->prepare("SELECT nombre FROM categorias WHERE nombre = :nombre");
    $stmt->bindParam(':nombre', $nombre);
    $stmt->execute();
    $categoria_exist = $stmt->fetch();

    if ($categoria_exist) {
        // Si la categoría ya existe, retorna false
        return false;
    } else {
        // Preparar la consulta SQL
        $stmt = $con->prepare("INSERT INTO categorias (nombre, estado, codigoCategoriaPadre) VALUES (:nombre, :estado, :codigoCategoriaPadre)");

        // Bind de parámetros
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':estado', $estado);
        $stmt->bindParam(':codigoCategoriaPadre', $codigoCategoriaPadre);

        // Ejecutar la consulta y retornar true si tiene éxito
        return $stmt->execute();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir los datos del formulario
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $codigoCategoriaPadre = $_POST['codigoCategoriaPadre'];

    try {
        // Intentar insertar la categoría utilizando la función definida
        if (insertarCategoria($con, $nombre, $estado, $codigoCategoriaPadre)) {
            // Redirigir al usuario a la página de categorías si la inserción fue exitosa
            header("Location: panelAdministrador.php");
            exit();
        } else {
            // Si la categoría ya existe, redirigir a la página de error
            header("Location: categoriaError.php");
            exit();
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "No se han recibido datos del formulario.";
}
?>

