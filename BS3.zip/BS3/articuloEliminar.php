<?php
include("conectar.php");

if(isset($_POST['codigoArticulo'])) {
    $codigoArticulo = $_POST['codigoArticulo']; // Código de artículo a desactivar

    try {
        // Preparar la consulta SQL para desactivar el artículo
        $stmt = $con->prepare("UPDATE articulos SET estado = 0 WHERE codigoArticulo = :codigoArticulo");

        // Bind de parámetros
        $stmt->bindParam(':codigoArticulo', $codigoArticulo);

        // Ejecutar la consulta
        if ($stmt->execute()) {
            echo "El artículo ha sido desactivado";
            header("Location: panelAdministrador.php");
            exit(); // Finalizar la ejecución del script después de la redirección
        } else {
            echo "Error al desactivar el artículo";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "No se ha proporcionado un código de artículo válido";
}
?>
