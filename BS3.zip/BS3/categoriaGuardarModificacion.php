<?php
include("conectar.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los datos del formulario
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $codigoCategoria = $_POST['codigoCategoria'];
    $codigoCategoriaPadre = isset($_POST['codigoCategoriaPadre']) ? $_POST['codigoCategoriaPadre'] : null;

    try {
        // Verificar si el nombre de la categoría ya existe en la base de datos
        $stmt = $con->prepare("SELECT codigoCategoria FROM categorias WHERE nombre = :nombre AND codigoCategoria != :codigoCategoria");
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':codigoCategoria', $codigoCategoria);
        $stmt->execute();
        $categoria_exist = $stmt->fetch();

        if ($categoria_exist) {
            // Redirigir a categoriaError.php si el nombre de la categoría ya existe
            header("Location: categoriaError.php");
            exit();
        } else {
            // Preparar la consulta SQL para actualizar el registro
            $sql = "UPDATE categorias SET nombre=:nombre, estado=:estado, codigoCategoriaPadre=:codigoCategoriaPadre WHERE codigoCategoria=:codigoCategoria";
            $statement = $con->prepare($sql);

            // Ejecutar la consulta SQL
            if ($statement->execute(array(':nombre'=>$nombre, ':estado'=>$estado, ':codigoCategoriaPadre'=>$codigoCategoriaPadre, ':codigoCategoria'=>$codigoCategoria))) {
                echo "Los cambios se han guardado correctamente.";
                header("Location: panelAdministrador.php");
                exit();
            } else {
                echo "Ha ocurrido un error al intentar guardar los cambios.";
                header("Location: panelAdministrador.php");
                exit();
            }
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "No se han recibido datos del formulario.";
}
?>
