<?php
include("conectar.php");
include("seguridad.php");

try {
    // Preparar y ejecutar la consulta SQL
    $query = "SELECT codigoArticulo, nombre, descripcion, codigoCategoria, precio, imagen, descuento, estado FROM articulos WHERE estado = 1";

    // Verificar si se ha enviado un nombre para buscar
    if(isset($_GET['buscar']) && !empty($_GET['buscar'])) {
        $nombre = $_GET['buscar'];
        $query .= " AND nombre LIKE :nombre";
    }

    // Verificar si se ha enviado un parámetro para ordenar
    if(isset($_GET['ordenar'])) {
        $ordenar = $_GET['ordenar'];
        $query .= " ORDER BY $ordenar";
    }

    // Preparar y ejecutar la consulta SQL
    $statement = $con->prepare($query);

    // Vincular valores si es necesario
    if(isset($nombre)) {
        $nombre = "%$nombre%";
        $statement->bindParam(':nombre', $nombre, PDO::PARAM_STR);
    }

    $statement->execute();
    $articulos = $statement->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de Artículos</title>
    <link rel="stylesheet" href="css/tablaUsuarios.css"> <!-- Enlace al archivo CSS -->
</head>
<body>

<h2>Tabla de Artículos</h2>

<div class="table-container">
    <a href="articuloNuevoFormulario.php" class="btn">Agregar Nuevo Artículo</a> <!-- Enlace para agregar nuevo artículo -->
</div>

<form action="articulos.php" method="GET">
    <div class="search-container">
        <input type="text" name="buscar" placeholder="Buscar por nombre">
        <button type="submit" class="btn">Buscar</button>
    </div>
    <br>
    <div class="order-container">
        <label for="ordenar">Ordenar por:</label>
        <select name="ordenar" id="ordenar">
            <option value="nombre">Nombre</option>
            <option value="codigoCategoria">Categoría</option>
            <option value="precio">Precio</option>
        </select>
        <button type="submit" class="btn">Ordenar</button>
    </div>
</form>

<table>
    <thead>
        <tr>
            <th>Código de Artículo</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Categoría</th>
            <th>Precio</th>
            <th>Imagen</th>
            <th>Descuento</th>
            <th>Estado</th>
            <th>Modificar</th>
            <th>Eliminar</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($articulos as $articulo): ?>
        <tr>
            <td><?php echo $articulo['codigoArticulo']; ?></td>
            <td><?php echo $articulo['nombre']; ?></td>
            <td><?php echo $articulo['descripcion']; ?></td>
            <td><?php echo $articulo['codigoCategoria']; ?></td>
            <td><?php echo $articulo['precio']; ?></td>
            <td><img src="uploads/<?php echo $articulo['imagen']; ?>" alt="Imagen del artículo" style="width: 70px;"></td>
            <td><?php echo $articulo['descuento']; ?></td>
            <td><?php echo $articulo['estado']; ?></td>
            <td>
                <a href="articuloModificarFormulario.php?codigoArticulo=<?php echo $articulo['codigoArticulo']; ?>&nombre=<?php echo $articulo['nombre']; ?>&descripcion=<?php echo $articulo['descripcion']; ?>&codigoCategoria=<?php echo $articulo['codigoCategoria']; ?>&precio=<?php echo $articulo['precio']; ?>&imagen=<?php echo $articulo['imagen']; ?>&descuento=<?php echo $articulo['descuento']; ?>&estado=<?php echo $articulo['estado']; ?>" class="btn">Modificar</a>
            </td>
            <td>
                <form action="articuloConfirmacion.php" method="POST" onsubmit="return confirmarEliminar();">
                    <input type="hidden" name="codigoArticulo" value="<?php echo $articulo['codigoArticulo']; ?>">
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<button onclick="window.location.href='panelAdministrador.php'" class="btn">Volver</button>
<br>
<br>
<button onclick="window.location.href='articuloBaja.php'" class="btn">Artículos dados de Baja</button>

</body>
</html>
