<?php
include("conectar.php");
include("seguridad.php");

if(isset($_POST['codigoCategoria'])) {
    $codigoCategoria = $_POST['codigoCategoria']; // Código de categoría a desactivar

    try {
        // Preparar la consulta SQL para desactivar la categoría
        $stmt = $con->prepare("UPDATE categorias SET estado = 0 WHERE codigoCategoria = :codigoCategoria");

        
        $stmt->bindParam(':codigoCategoria', $codigoCategoria);

        // Ejecutar la consulta
        if ($stmt->execute()) {
            echo "La categoría ha sido desactivada";
            header("Location: panelAdministrador.php");
        } else {
            echo "Error al desactivar la categoría";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "No se ha proporcionado un código de categoría válido";
}
?>
