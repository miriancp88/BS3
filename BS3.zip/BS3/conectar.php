<?php

define("USER_DB", "root");
define("PASSWORD", "");

try {
    $dsn = "mysql:host=localhost;dbname=bs3.1;charset=utf8mb4";
    $con = new PDO($dsn, USER_DB, PASSWORD);
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}
?>