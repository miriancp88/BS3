<?php
include("conectar.php");

include("seguridad.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/modificarUsuarioFormulario.css">
    <title>Agregar Nueva Categoría</title>
</head>
<body>

<div class="container">
    <h2>Agregar Nueva Categoría</h2>
    <form action="categoriaInsertar.php" method="POST">
        <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>
        </div>
        <div class="form-group">
            <label for="estado">Estado:</label>
            <select id="estado" name="estado" required>
                <option value="1">Activo</option>
                <option value="0">Inactivo</option>                
            </select>
        </div>
        <div class="form-group">
            <label for="codigoCategoriaPadre">Código de Categoría Padre:</label>
            <input type="text" id="codigoCategoriaPadre" name="codigoCategoriaPadre">
        </div>
        <button type="submit" class="btn">Agregar Categoría</button>
        <button onclick="window.location.href='panelAdministrador.php'" class="btn">Volver</button>
    </form>
</div>

</body>
</html>
