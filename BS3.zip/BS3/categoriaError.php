<?php
include("header.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Error: categoria repetida</title>
</head>
<body>
    <h1>Error: categoria ya registrada</h1>
    
 
</body>
</html>