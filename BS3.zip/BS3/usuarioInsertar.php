

function verificarDniExistente($con, $dni) {
    $stmt = $con->prepare("SELECT dni FROM usuarios WHERE dni = :dni");
    $stmt->bindParam(':dni', $dni);
    $stmt->execute();
    return $stmt->fetch();
}

function verificarEmailExistente($con, $email) {
    $stmt = $con->prepare("SELECT email FROM usuarios WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    return $stmt->fetch();
}

function insertarUsuario($con, $dni, $nombre, $email, $password, $direccion, $rol, $estado) {
    try {
        // Hacer un hash de la contraseña
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Preparar la consulta SQL
        $stmt = $con->prepare("INSERT INTO usuarios (dni, nombre, email, password, direccion, rol, estado) VALUES (:dni, :nombre, :email, :password, :direccion, :rol, :estado)");

        // Bind de parámetros
        $stmt->bindParam(':dni', $dni);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashed_password); // Usar la contraseña con hash
        $stmt->bindParam(':direccion', $direccion);
        $stmt->bindParam(':rol', $rol);
        $stmt->bindParam(':estado', $estado);

        // Ejecutar la consulta
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return false;
    }
}

// Recibir los datos del formulario
$dni = $_POST['dni'];
$nombre = $_POST['nombre'];
$email = $_POST['email'];
$password = $_POST['password'];
$direccion = $_POST['direccion'];
$rol = $_POST['rol'];
$estado = $_POST['estado'];

// Verificar duplicados
$dni_exist = verificarDniExistente($con, $dni);
$email_exist = verificarEmailExistente($con, $email);

if ($dni_exist) {
    echo "<script>alert('El DNI ya está registrado. Por favor, ingresa otro DNI.'); window.location.href = 'panelAdministrador.php';</script>";
} elseif ($email_exist) {
    echo "<script>alert('El correo electrónico ya está registrado. Por favor, ingresa otro correo electrónico.'); window.location.href = 'panelAdministrador.php';</script>";
} else {
    // Insertar usuario
    if (insertarUsuario($con, $dni, $nombre, $email, $password, $direccion, $rol, $estado)) {
        header("Location: panelAdministrador.php");
        exit();
    } else {
        echo "Error al crear el registro.";
    }
}
?>

