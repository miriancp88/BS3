<?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="es">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BS3</title>
    <link rel="stylesheet" href="css/contacto.css">
    
</head>
    <section class="contacto">
        <h2>Contacto</h2>
        
        <div class="detalles-contacto">
            <p><strong>Correo electrónico:</strong> info@bs3.com</p>
            <p><strong>Teléfono:</strong> +34 62045896</p>
            <p><strong>Dirección:</strong> Calle Principal, 123, Elche, España</p>
        </div>
    </section>

<?php include_once "footer.php"; ?> 


</body>
</html>
