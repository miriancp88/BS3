<?php
include("conectar.php");
include("seguridad.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los datos del formulario
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $codigoCategoria = $_POST['codigoCategoria'];
    $precio = $_POST['precio'];
    $imagen = $_FILES['imagen']['name'];
    $descuento = $_POST['descuento'];
    $estado = $_POST['estado'];
    $codigoArticulo = $_POST['codigoArticulo'];

    // Subir la nueva imagen al servidor
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["imagen"]["name"]);

    try {
        // Verificar si se ha subido una nueva imagen
        if ($_FILES['imagen']['size'] > 0) {
            
            if (move_uploaded_file($_FILES["imagen"]["tmp_name"], $target_file)) {
                // Actualizar la columna imagen en la base de datos
                $stmt = $con->prepare("UPDATE articulos SET imagen = :imagen WHERE codigoArticulo = :codigoArticulo");
                $stmt->bindParam(':imagen', $imagen);
                $stmt->bindParam(':codigoArticulo', $codigoArticulo);
                $stmt->execute();
            } else {
                // Manejar error si la imagen no se pudo subir
                echo "Error al subir la nueva imagen.";
                exit();
            }
        }

        // Preparar la consulta SQL para actualizar el registro
        $sql = "UPDATE articulos SET nombre=:nombre, descripcion=:descripcion, codigoCategoria=:codigoCategoria, precio=:precio, descuento=:descuento, estado=:estado WHERE codigoArticulo=:codigoArticulo";
        $statement = $con->prepare($sql);

        // Ejecutar la consulta SQL
        $statement->bindParam(':nombre', $nombre);
        $statement->bindParam(':descripcion', $descripcion);
        $statement->bindParam(':codigoCategoria', $codigoCategoria);
        $statement->bindParam(':precio', $precio);
        $statement->bindParam(':descuento', $descuento);
        $statement->bindParam(':estado', $estado);
        $statement->bindParam(':codigoArticulo', $codigoArticulo);

        if ($statement->execute()) {
            echo "Los cambios se han guardado correctamente.";
            header("Location: panelAdministrador.php");
            exit();
        } else {
            echo "Ha ocurrido un error al intentar guardar los cambios.";
            header("Location: panelAdministrador.php");
            exit();
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "No se han recibido datos del formulario.";
}
?>
