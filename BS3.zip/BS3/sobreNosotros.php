<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BS3</title>
    <link rel="stylesheet" href="css/quiensomos.css">
</head>
<body>

    <section class="quienes-somos">
        <h2>BS3</h2>
        <div class="descripcion">
            <img src="imagenes/yo.jpg" alt="Mirian Cabrera Parra - Web Developer y Dueña de la Tienda" >
            <p>Hola, soy Mirian Cabrera Parra, la fundadora y propietaria de esta tienda de gafas. Además de ser la mente creativa detrás de nuestro sitio web, soy una apasionada por la moda y la calidad. Con un enfoque en la innovación y el diseño, nuestra tienda busca ofrecer a nuestros clientes las últimas tendencias en gafas de sol.</p>
            <p>Las gafas de sol no solo son un accesorio de moda, también son una forma de proteger nuestros ojos de los rayos dañinos del sol. En nuestra tienda, nos esforzamos por ofrecer una amplia gama de estilos que se adapten a todos los gustos y necesidades, sin comprometer la calidad ni la protección ocular.</p>
            <p>Con el compromiso de brindar un excelente servicio al cliente y productos de alta calidad, estamos encantados de ser tu destino número uno para todas tus necesidades de gafas de sol.</p>
        </div>
    </section>
 
 
<?php include_once "footer.php"; ?> 


    
</body>
</html>
