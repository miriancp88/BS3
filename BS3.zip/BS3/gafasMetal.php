<?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="es">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BS3</title>
    <link rel="stylesheet" href="css/articulos.css">
    
</head>

    
    <div class="container">
        <?php
        // Verificar si las constantes no están definidas
        if (!defined('USER_DB') && !defined('PASSWORD')) {
            include 'conectar.php';
        }
        try {
            $query = "SELECT * FROM articulos WHERE codigoCategoria = 2"; 
            $stmt = $con->query($query);
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                // Calcular el nuevo precio si hay descuento
                $precio = $row['precio'];
                if (!empty($row['descuento'])) {
                    $nuevo_precio = $precio - $row['descuento'];
                    $precio = $nuevo_precio < 0 ? 0 : $nuevo_precio;
                }
                ?>
                <div class="card">
                    <img src="uploads/<?php echo $row['imagen']; ?>" alt="Imagen del artículo" style="width: 500px;">
                    <div class="card-body">
                        <h3 class="card-title"><?php echo $row['nombre']; ?></h3>
                        <p class="card-description"><?php echo $row['descripcion']; ?></p>
                        <?php if (!empty($row['descuento'])): ?>
                            <p class="card-price"><?php echo $precio; ?>€ <span style="text-decoration: line-through; color: red;"><?php echo $row['precio']; ?>€</span></p>
                    
                <?php else: ?>
                    <p class="card-price"><?php echo $precio; ?>€</p>
                <?php endif; ?>
                <form action="carrito.php" method="post">
                            <input type="hidden" name="codigoArticulo" value="<?php echo $row['codigoArticulo']; ?>">
                            <button type="submit" class="add-to-cart-btn">Añadir al carrito</button>
                        </form>
                    </div>
                </div>
                <?php
            }
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
        ?>
    </div>

    <?php include_once "left-sidebar.php"; ?> 
<?php include_once "right-sidebar.php"; ?> 
<?php include_once "footer.php"; ?> 

  
</body>
</html>
