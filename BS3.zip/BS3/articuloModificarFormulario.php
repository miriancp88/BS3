<?php
include("conectar.php");

include("seguridad.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Artículo</title>
    <link rel="stylesheet" href="css/modificarUsuarioFormulario.css"> <!-- Enlace al archivo CSS -->
</head>
<body>

<div class="container">
    <h2>Modificar Artículo</h2>
    <form action="articuloGuardarModificacion.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" placeholder="Nombre del artículo" value="<?php echo isset($_GET['nombre']) ? $_GET['nombre'] : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="descripcion">Descripción:</label>
            <textarea id="descripcion" name="descripcion" placeholder="Descripción del artículo" required><?php echo isset($_GET['descripcion']) ? $_GET['descripcion'] : ''; ?></textarea>
        </div>
        <div class="form-group">
            <label for="codigoCategoria">Código de Categoría:</label>
            <input type="text" id="codigoCategoria" name="codigoCategoria" placeholder="Código de la categoría" value="<?php echo isset($_GET['codigoCategoria']) ? $_GET['codigoCategoria'] : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="precio">Precio:</label>
            <input type="number" id="precio" name="precio" placeholder="Precio del artículo" step="0.01" value="<?php echo isset($_GET['precio']) ? $_GET['precio'] : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="imagen">Imagen:</label>
            <input type="file" id="imagen" name="imagen">
            <?php if(isset($_GET['imagen'])): ?>
                <p>Imagen actual: <img src="<?php echo $_GET['imagen']; ?>" alt="Imagen actual del artículo" "></p>
            <?php endif; ?>
       </div>
        <div class="form-group">
            <label for="descuento">Descuento:</label>
            <input type="number" id="descuento" name="descuento" placeholder="Descuento del artículo" step="0.01" value="<?php echo isset($_GET['descuento']) ? $_GET['descuento'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="estado">Estado:</label>
            <select id="estado" name="estado" required>
                <option value="1" <?php echo ($_GET['estado'] == '1') ? 'selected' : ''; ?>>Activo</option>
                <option value="0" <?php echo ($_GET['estado'] == '0') ? 'selected' : ''; ?>>Inactivo</option>
            </select>
        </div>
        <input type="hidden" name="codigoArticulo" value="<?php echo $_GET['codigoArticulo']; ?>">
        <button type="submit" class="btn">Guardar Cambios</button>
        <button onclick="window.location.href='panelAdministrador.php'" class="btn">Volver</button>
    </form>
</div>

</body>
</html>
