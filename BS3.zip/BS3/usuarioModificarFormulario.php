<?php

include("seguridad.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Usuario</title>
    <link rel="stylesheet" href="css/modificarUsuarioFormulario.css"> 
</head>
<body>

<div class="container">
    <h2>Modificar Usuario</h2>
    <form action="usuarioGuardarMoficacion.php" method="POST">
              <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" placeholder="Nombre del usuario" value="<?php echo isset($_GET['nombre']) ? $_GET['nombre'] : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" placeholder="Email del usuario" value="<?php echo isset($_GET['email']) ? $_GET['email'] : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="password">Nueva contraseña:</label>
            <input type="password" id="password" name="password" placeholder="Nueva contraseña">
        </div>
        <div class="form-group">
            <label for="direccion">Dirección:</label>
            <input type="text" id="direccion" name="direccion" placeholder="Dirección del usuario" value="<?php echo isset($_GET['direccion']) ? $_GET['direccion'] : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="rol">Rol:</label>
            <select id="rol" name="rol" required>
                <option value="administrador" <?php echo ($_GET['rol'] == 'administrador') ? 'selected' : ''; ?>>Administrador</option>
                <option value="empleado" <?php echo ($_GET['rol'] == 'empleado') ? 'selected' : ''; ?>>Empleado</option>
                <option value="cliente" <?php echo ($_GET['rol'] == 'cliente') ? 'selected' : ''; ?>>Cliente</option>
            </select>
        </div>
       
        <div class="form-group">
             <label for="estado">Estado:</label>
                <select id="estado" name="estado" required>
                <option value="1" <?php echo ($_GET['estado'] == '1') ? 'selected' : ''; ?>>Activo</option>
                <option value="0" <?php echo ($_GET['estado'] == '0') ? 'selected' : ''; ?>>Inactivo</option>
            </select>
        </div>

        <input type="hidden" name="dni" value="<?php echo $_GET['dni']; ?>">
        <button type="submit" class="btn">Guardar Cambios</button>
        <button onclick="window.location.href='panelAdministrador.php'" class="btn">Volver</button>
    </form>
</div>

</body>
</html>
