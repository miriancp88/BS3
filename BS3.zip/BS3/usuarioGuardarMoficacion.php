<?php
include("conectar.php"); 

include("seguridad.php");


function actualizarUsuario($con, $nombre, $email, $direccion, $rol, $estado, $dni) {
    try {
        // Preparar la consulta SQL para actualizar el registro
        $sql = "UPDATE usuarios SET nombre=:nombre, email=:email, direccion=:direccion, rol=:rol, estado=:estado WHERE dni=:dni";
        $statement = $con->prepare($sql);

        // Ejecutar la consulta SQL
        if ($statement->execute(array(':nombre'=>$nombre, ':email'=>$email, ':direccion'=>$direccion, ':rol'=>$rol, ':estado'=>$estado, ':dni'=>$dni))) {
            return true;
        } else {
            return false;
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los datos del formulario
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $direccion = $_POST['direccion'];
    $rol = $_POST['rol'];
    $estado = $_POST['estado'];
    $dni = $_POST['dni'];

    // Actualizar usuario
    if (actualizarUsuario($con, $nombre, $email, $direccion, $rol, $estado, $dni)) {
        echo "Los cambios se han guardado correctamente.";
        header("Location: panelAdministrador.php");
        exit();
    } else {
        echo "Ha ocurrido un error al intentar guardar los cambios.";
        header("Location: panelAdministrador.php");
        exit();
    }
} else {
    echo "No se han recibido datos del formulario.";
}
?>
