<?php
session_start(); // Iniciar sesión
include_once "conectar.php"; // Incluir archivo de conexión a la base de datos

function obtenerRolUsuario($con, $email) {
    $rolUsuario = null;
    try {
        // Obtener el rol del usuario de la base de datos
        $stmt = $con->prepare("SELECT rol FROM usuarios WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $rolUsuario = $result['rol']; // Rol del usuario
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }
    return $rolUsuario;
}

function generarMenuNavegacion($rolUsuario) {
    // Generar el menú de navegación según el rol del usuario
    $menu = '<header>
                <div class="logo-container">
                    <img src="Imagenes/logo.png" alt="Logo">
                </div>
                <nav>
                    <ul>';
    if ($rolUsuario == "administrador") {
        $menu .= '<li><a href="#" onclick="cargarContenido(\'usuarios.php\')">USUARIOS</a></li>';
    }
    $menu .= '<li><a href="#" onclick="cargarContenido(\'articulos.php\')">ARTICULOS</a></li>
              <li><a href="#" onclick="cargarContenido(\'categorias.php\')">CATEGORIAS PRODUCTOS</a></li>
              <li><a href="#" onclick="cargarContenido(\'pedidos.php\')">PEDIDOS</a></li>
            </ul>
        </nav>
        <div class="user-cart">
            <a href="index.php">PAGINA DE VENTA</a>
        </div>
    </header>';
    return $menu;
}

$rolUsuario = null;
if (isset($_SESSION['autentificado']) && $_SESSION['autentificado'] == "OK") {
    $email = $_SESSION['usuario'];
    $rolUsuario = obtenerRolUsuario($con, $email);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BS3</title>
    <link rel="stylesheet" href="css/panelAdministradorNav.css">
</head>
<body>
    <?php echo generarMenuNavegacion($rolUsuario); ?>

    <div class="contenido" id="contenido">
        <!-- Contenido se cargará aquí -->
    </div>

    <script>
        function cargarContenido(url) {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("contenido").innerHTML = this.responseText;
                }
            };
            xhttp.open("GET", url, true);
            xhttp.send();
        }
    </script>
</body>
</html>
