<?php
include("conectar.php");
include("seguridad.php");

try {
    // Preparar y ejecutar la consulta SQL
    $query = "SELECT codigoCategoria, nombre, estado, codigoCategoriaPadre FROM categorias WHERE estado = 1";

    // Verificar si se ha enviado un nombre para buscar
    if(isset($_GET['buscar']) && !empty($_GET['buscar'])) {
        $nombre = $_GET['buscar'];
        $query .= " AND nombre LIKE :nombre";
    }

    // Verificar si se ha enviado un parámetro para ordenar
    if(isset($_GET['ordenar'])) {
        $ordenar = $_GET['ordenar'];
        // Si el orden es por categoría padre, se ordena primero por nombre y luego por categoría padre
        if($ordenar == 'codigoCategoriaPadre') {
            $query .= " ORDER BY nombre, codigoCategoriaPadre";
        } else {
            $query .= " ORDER BY $ordenar";
        }
    }

    // Preparar y ejecutar la consulta SQL
    $statement = $con->prepare($query);

    // Vincular valores si es necesario
    if(isset($nombre)) {
        $nombre = "%$nombre%";
        $statement->bindParam(':nombre', $nombre, PDO::PARAM_STR);
    }

    $statement->execute();
    $categorias = $statement->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de Categorías</title>
    <link rel="stylesheet" href="css/tablaUsuarios.css"> 
</head>
<body>

<h2>Tabla de Categorías</h2>


<div class="table-container">
    <a href="categoriaNuevaFormulario.php" class="btn">Agregar Nueva Categoría</a>
</div>


<form action="categorias.php" method="GET">
    <div class="search-container">
        <input type="text" name="buscar" placeholder="Buscar por nombre">
        <button type="submit" class="btn">Buscar</button>
    </div>
    <br>
    <div class="order-container">
        <label for="ordenar">Ordenar por:</label>
        <select name="ordenar" id="ordenar">
            <option value="nombre">Nombre</option>
            <option value="codigoCategoriaPadre">Categoría Padre</option>
           
        </select>
        <button type="submit" class="btn">Ordenar</button>
    </div>
</form>

<!-- Tabla de categorías -->
<table>
    <thead>
        <tr>
            <th>Código</th>
            <th>Nombre</th>
            <th>Estado</th>
            <th>Categoría Padre</th>
            <th>Modificar</th>
            <th>Eliminar</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($categorias as $categoria): ?>
        <tr>
            <td><?php echo $categoria['codigoCategoria']; ?></td>
            <td><?php echo $categoria['nombre']; ?></td>
            <td><?php echo $categoria['estado']; ?></td>
            <td><?php echo $categoria['codigoCategoriaPadre']; ?></td>
            <td>
                <!-- Enlace para modificar categoría -->
                <a href="categoriaModificarFormulario.php?codigoCategoria=<?php echo $categoria['codigoCategoria']; ?>&nombre=<?php echo $categoria['nombre']; ?>&estado=<?php echo $categoria['estado']; ?>&codigoCategoriaPadre=<?php echo $categoria['codigoCategoriaPadre']; ?>" class="btn">Modificar</a>
            </td>
            <td>
                <!-- Formulario para eliminar categoría -->
                <form action="categoriaConfirmacion.php" method="POST" onsubmit="return confirmarEliminar();">
                    <input type="hidden" name="codigoCategoria" value="<?php echo $categoria['codigoCategoria']; ?>">
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<button onclick="window.location.href='panelAdministrador.php'" class="btn">Volver</button>
<br>
<br>
<button onclick="window.location.href='categoriaBaja.php'" class="btn">Categorías dados de Baja</button>

</body>
</html>
