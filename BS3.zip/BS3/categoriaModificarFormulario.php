<?php
include("conectar.php");

include("seguridad.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Categoría</title>
    <link rel="stylesheet" href="css/modificarUsuarioFormulario.css"> <!-- Enlace al archivo CSS -->
</head>
<body>

<div class="container">
    <h2>Modificar Categoría</h2>
    <form action="categoriaGuardarModificacion.php" method="POST">
        <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" placeholder="Nombre de la categoría" value="<?php echo isset($_GET['nombre']) ? $_GET['nombre'] : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="estado">Estado:</label>
            <select id="estado" name="estado" required>
                <option value="1" <?php echo ($_GET['estado'] == '1') ? 'selected' : ''; ?>>Activo</option>
                <option value="0" <?php echo ($_GET['estado'] == '0') ? 'selected' : ''; ?>>Inactivo</option>
            </select>
        </div>
        <div class="form-group">
            <label for="codigoCategoriaPadre">Código de Categoría Padre:</label>
            <input type="text" id="codigoCategoriaPadre" name="codigoCategoriaPadre" placeholder="Código de la categoría padre" value="<?php echo isset($_GET['codigoCategoriaPadre']) ? $_GET['codigoCategoriaPadre'] : ''; ?>">
        </div>
        <input type="hidden" name="codigoCategoria" value="<?php echo $_GET['codigoCategoria']; ?>">
        <button type="submit" class="btn">Guardar Cambios</button>
        <button onclick="window.location.href='panelAdministrador.php'" class="btn">Volver</button>
    </form>
</div>

</body>
</html>
