<?php
include('conectar.php'); 
include('header.php'); 

function getProductosPorCategoria($codigoCategoria) {
    global $con;
    $productos = [];
    try {
        // Consulta para obtener productos de la categoría principal y todas sus subcategorías
        $stmt = $con->prepare("
            SELECT articulos.* FROM articulos
            INNER JOIN categorias ON articulos.codigoCategoria = categorias.codigoCategoria
            WHERE (categorias.codigoCategoria = :codigoCategoria OR categorias.codigoCategoriaPadre = :codigoCategoria)
            AND articulos.estado = 1
        ");
        $stmt->bindParam(':codigoCategoria', $codigoCategoria, PDO::PARAM_INT);
        $stmt->execute();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $precio = $row['precio'];
            $descuento = $row['descuento'];
            // Calcular el nuevo precio con la función calcularPrecioConDescuento
            $nuevo_precio = calcularPrecioConDescuento($precio, $descuento);
            $producto = array(
                'nombre' => $row['nombre'],
                'descripcion' => $row['descripcion'],
                'imagen' => $row['imagen'],
                'precio' => $nuevo_precio, // Usar el nuevo precio calculado
                'precioOriginal' => $precio,
                'descuento' => $descuento,
                'codigoArticulo' => $row['codigoArticulo']
            );
            $productos[] = $producto;
        }
        return $productos;
    } catch (PDOException $e) {
        die('Error: ' . $e->getMessage());
    }
}

if (isset($_GET['cat'])) {
    $codigoCategoria = $_GET['cat'];
    $productos = getProductosPorCategoria($codigoCategoria);
    ?>
    <div class="container">
    <?php foreach ($productos as $producto): ?>
        <div class="card">
            <img src="uploads/<?php echo $producto['imagen']; ?>" alt="<?php echo $producto['nombre']; ?>" style="width: 450px;">
            <div class="card-body">
                <h3 class="card-title"><?php echo $producto['nombre']; ?></h3>
                <p class="card-description"><?php echo $producto['descripcion']; ?></p>
                <?php if ($producto['descuento'] > 0): ?>
                    <p class="card-price"><?php echo number_format($producto['precio'], 2); ?>€ <span style="text-decoration: line-through; color: red;"><?php echo number_format($producto['precioOriginal'], 2); ?>€</span></p>
                <?php else: ?>
                    <p class="card-price"><?php echo number_format($producto['precio'], 2); ?>€</p>
                <?php endif; ?>
                <form action="carrito.php" method="post">
                    <input type="hidden" name="codigoArticulo" value="<?php echo $producto['codigoArticulo']; ?>">
                    <button type="submit" class="add-to-cart-btn">Añadir al carrito</button>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
    <?php
} else {
    echo "No se especificó una categoría.";
}
include 'left-sidebar.php';   
include 'right-sidebar.php';
include('footer.php'); 

// Función para calcular el precio con descuento
function calcularPrecioConDescuento($precio, $descuento) {
    $nuevo_precio = $precio - $descuento;
    return $nuevo_precio < 0 ? 0 : $nuevo_precio;
}
?>

