<?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="es">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BS3</title>
    
    
</head>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Error: DNI o Email ya registrados</title>
</head>
<body>
    <h1>Error: DNI o Email ya registrados</h1>
    <p>Lo sentimos, el DNI o el correo electrónico ya están registrados en nuestro sistema.</p>
    <p>Por favor, vuelva atrás e intente registrarse con una información diferente.</p>
 
</body>
</html>
