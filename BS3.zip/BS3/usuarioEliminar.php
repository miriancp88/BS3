<?php
include("conectar.php");

include("seguridad.php");
?>

function desactivarUsuario($con, $dni) {
    try {
        // Preparar la consulta SQL para desactivar el usuario
        $stmt = $con->prepare("UPDATE usuarios SET estado = 0 WHERE dni = :dni");

        // Bind de parámetros
        $stmt->bindParam(':dni', $dni);

        // Ejecutar la consulta
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return false;
    }
}

if(isset($_POST['dni'])) {
    $dni = $_POST['dni']; // DNI del usuario a desactivar
    // Desactivar usuario
    if (desactivarUsuario($con, $dni)) {
        echo "El usuario ha sido desactivado";
        header("Location: panelAdministrador.php");
        exit();
    } else {
        echo "Error al desactivar el usuario";
    }
} else {
    echo "No se ha proporcionado un DNI de usuario válido";
}
?>
