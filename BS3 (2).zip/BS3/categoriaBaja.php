<?php
include 'conectar.php';
include 'seguridad.php';

// Función para ejecutar una consulta SQL con parámetros opcionales
function ejecutarConsulta($con, $query, $params = []) {
    $statement = $con->prepare($query);
    $statement->execute($params);
    return $statement->fetchAll(PDO::FETCH_ASSOC);
}

// Función para generar las filas de la tabla de categorías
function generarFilasCategorias($categorias) {
    foreach ($categorias as $categoria): ?>
        <tr>
            <td><?php echo $categoria['codigoCategoria']; ?></td>
            <td><?php echo $categoria['nombre']; ?></td>
            <td><?php echo $categoria['estado']; ?></td>
            <td><?php echo $categoria['codigoCategoriaPadre']; ?></td>
            <td>
                <a href="categoriaModificarFormulario.php?codigoCategoria=<?php echo $categoria['codigoCategoria']; ?>&nombre=<?php echo $categoria['nombre']; ?>&estado=<?php echo $categoria['estado']; ?>&codigoCategoriaPadre=<?php echo $categoria['codigoCategoriaPadre']; ?>" class="btn">Modificar</a>
            </td>
        </tr>
    <?php endforeach;
}

// Definir la consulta SQL base
$query = "SELECT codigoCategoria, nombre, estado, codigoCategoriaPadre FROM categorias WHERE estado = 0";

// Verificar si se ha enviado un nombre para buscar
if(isset($_GET['buscar'])) {
    $nombre = $_GET['buscar'];
    $query .= " AND nombre LIKE :nombre";
}

// Verificar si se ha enviado un parámetro para ordenar
if(isset($_GET['ordenar'])) {
    $ordenar = $_GET['ordenar'];
    $query .= " ORDER BY $ordenar";
}

try {
    // Ejecutar la consulta SQL y obtener las categorías
    $categorias = ejecutarConsulta($con, $query, isset($nombre) ? [':nombre' => "%$nombre%"] : []);

} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de Categorías</title>
    <link rel="stylesheet" href="css/tablaUsuarios.css"> <!-- Enlace al archivo CSS -->
</head>
<body>
    <h2>Tabla de Categorías</h2>

    
    <form action="categorias.php" method="GET">
        <div class="search-container">
            <input type="text" name="buscar" placeholder="Buscar por nombre">
            <button type="submit" class="btn">Buscar</button>
        </div>
        <br>
        <div class="order-container">
            <label for="ordenar">Ordenar por:</label>
            <select name="ordenar" id="ordenar">
                <option value="nombre">Nombre</option>
                <option value="estado">Estado</option>
            </select>
            <button type="submit" class="btn">Ordenar</button>
        </div>
    </form>

    <table>
        <thead>
            <tr>
                <th>Código de Categoría</th>
                <th>Nombre</th>
                <th>Estado</th>
                <th>Código de Categoría Padre</th>
                <th>Modificar</th>
            </tr>
        </thead>
        <tbody>
            <?php generarFilasCategorias($categorias); ?>
        </tbody>
    </table>

    <button onclick="window.location.href='panelAdministrador.php'" class="btn">Volver</button>
    <br>
    <br>
</body>
</html>
