<?php
session_start();

// Verifica si se ha enviado el código del artículo para eliminar del carrito
if (isset($_POST['eliminarArticulo'])) {
    $codigoArticulo = $_POST['codigoArticulo'];
    eliminarDelCarrito($codigoArticulo);
}

// Función para eliminar un artículo del carrito
function eliminarDelCarrito($codigoArticulo) {
    // Verifica si el carrito está vacío
    if (!empty($_SESSION['carrito'])) {
        // Itera sobre los elementos del carrito
        foreach ($_SESSION['carrito'] as $key => $item) {
            // Si encuentra el artículo en el carrito
            if ($item['codigoArticulo'] === $codigoArticulo) {
                // Si la cantidad es mayor a 1, simplemente resta 1 a la cantidad
                if ($item['cantidad'] > 1) {
                    $_SESSION['carrito'][$key]['cantidad'] -= 1;
                } else {
                    // Si la cantidad es 1, elimina el artículo del carrito
                    unset($_SESSION['carrito'][$key]);
                    // Reindexa el array después de eliminar un elemento
                    $_SESSION['carrito'] = array_values($_SESSION['carrito']);
                }
                // Redirige de vuelta a carrito.php después de eliminar el artículo
                header("Location: carrito.php");
                exit(); // Asegura que el script termine después de la redirección
            }
        }
    }
}
?>

