<?php
include("conectar.php");
include("seguridad.php");

// Recibir los datos del formulario
$dni = $_POST['dni'];
$nombre = $_POST['nombre'];
$email = $_POST['email'];
$password = $_POST['password'];
try {
  $direccion = $_POST['direccion'];
$rol = 'cliente';
$estado = '1';

  // Verificar si el DNI ya existe en la base de datos
    $stmt = $con->prepare("SELECT dni FROM usuarios WHERE dni = :dni");
    $stmt->bindParam(':dni', $dni);
    $stmt->execute();
    $dni_exist = $stmt->fetch();

    // Verificar si el correo electrónico ya existe en la base de datos
    $stmt = $con->prepare("SELECT email FROM usuarios WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $email_exist = $stmt->fetch();

    if ($dni_exist) {
        echo "<script>alert('El DNI ya está registrado. Por favor, ingresa otro DNI.'); window.location.href = 'login.php';</script>";
    } elseif ($email_exist) {
        echo "<script>alert('El correo electrónico ya está registrado. Por favor, ingresa otro correo electrónico.'); window.location.href = 'login.php';</script>";
    } else {
        // Hacer un hash de la contraseña
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Preparar la consulta SQL
        $stmt = $con->prepare("INSERT INTO usuarios (dni, nombre, email, password, direccion, rol, estado) VALUES (:dni, :nombre, :email, :password, :direccion, :rol, :estado)");

        // Bind de parámetros
        $stmt->bindParam(':dni', $dni);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashed_password); // Usar la contraseña con hash
        $stmt->bindParam(':direccion', $direccion);
        $stmt->bindParam(':rol', $rol);
        $stmt->bindParam(':estado', $estado);

        // Ejecutar la consulta
        if ($stmt->execute()) {
            echo "¡Registro creado satisfactoriamente!";
            // Redirigir al usuario a la página de usuarios
            header("Location: login.php");
            exit(); // Finalizar la ejecución del script
        } else {
            echo "Error al crear el registro.";
        }
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>

