<?php
session_start();
include_once "header.php";
include_once "conectar.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];

    // Verificar si el correo electrónico existe en la base de datos
    $stmt = $con->prepare("SELECT * FROM usuarios WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch();

    if ($user) {
        // Actualizar la contraseña en la base de datos
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $con->prepare("UPDATE usuarios SET password = :password WHERE email = :email");
        $stmt->bindParam(':password', $hashed_password);
        $stmt->bindParam(':email', $email);
        if ($stmt->execute()) {
            $success_message = "Contraseña actualizada correctamente.";
        } else {
            $error_message = "Error al actualizar la contraseña. Por favor, inténtelo de nuevo.";
        }
    } else {
        $error_message = "El correo electrónico proporcionado no está registrado en nuestro sistema.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña</title>
    <link rel="stylesheet" href="css/loginStyles.css">
</head>
<body>
    <div class="login-container">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <h2>Recuperar Contraseña</h2>
            <?php if (isset($error_message)) : ?>
                <div class="error"><?php echo $error_message; ?></div>
            <?php endif; ?>
            <?php if (isset($success_message)) : ?>
                <div class="success"><?php echo $success_message; ?></div>
            <?php endif; ?>
            <div class="input-group">
                <label>Email:</label>
                <input type="email" name="email" required>
            </div>
            <div class="input-group">
                <label>Nueva Contraseña:</label>
                <input type="password" name="new_password" required>
            </div>
            <div class="input-group">
                <button type="submit">Actualizar Contraseña</button>
            </div>
        </form>
    </div>
</body>
</html>

