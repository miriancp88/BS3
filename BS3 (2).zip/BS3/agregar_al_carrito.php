<?php
session_start();
include_once "conectar.php"; // Incluir el archivo que contiene la conexión a la base de datos
include_once "seguridad.php";
// Verificar si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener el ID del artículo desde el formulario
    $codigoArticulo = $_POST['codigoArticulo'];

    // Consultar la base de datos para obtener los detalles específicos del artículo
    $query = "SELECT nombre, imagen, precio FROM articulos WHERE codigoArticulo = :codigoArticulo";
    $statement = $con->prepare($query);
    $statement->bindParam(':codigoArticulo', $codigoArticulo, PDO::PARAM_INT);
    $statement->execute();
    $articulo = $statement->fetch(PDO::FETCH_ASSOC);

    // Verificar si se encontró el artículo
    if ($articulo) {
        // Agregar los detalles específicos del artículo al carrito (usando una variable de sesión)
        $_SESSION['carrito'][] = [
            'nombre' => $articulo['nombre'],
            'imagen' => $articulo['imagen'],
            'precio' => $articulo['precio'],
            'descuento' => $articulo['descuento']
        ];
        
        // Redirigir de vuelta a la página de productos o a donde sea apropiado
        header("Location: carrito.php");
        exit();
    } else {
        // Manejar el caso en que el artículo no se encuentra en la base de datos
        echo "El artículo no se encontró en la base de datos.";
    }
}
?>

