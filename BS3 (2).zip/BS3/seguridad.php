<?php
// Verificar si no hay una sesión activa
if (session_status() === PHP_SESSION_NONE) {
    // Inicio de sesión
    session_start();
}

// Comprueba si el usuario está autenticado
if (!isset($_SESSION['autentificado']) || $_SESSION['autentificado'] !== "OK") {
    // Si no está autenticado, redirige a la página de inicio de sesión
    header("Location: login.php");
    // Finaliza el script
    exit();
}
?>
