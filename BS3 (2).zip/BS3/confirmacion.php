<?php
include("conectar.php");
include("seguridad.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/confirmacion.css">
    <title>Confirmación de Eliminación</title>
</head>
<body>

<h2>Confirmación de Eliminación</h2>

<p>¿Está seguro de eliminar este registro?</p>

<form action="usuarioEliminar.php" method="POST">
    <input type="hidden" name="dni" value="<?php echo $_POST['dni']; ?>">
    <button type="submit">SI</button>
</form>

<a href="panelAdministrador.php" class="btn">NO</a>

</body>
</html>
