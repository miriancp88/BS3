<?php
session_start();
include_once "conectar.php"; 
include_once 'header.php'; 
function autenticarUsuario($con, $email, $password) {
    $error_message = "";

    // Obtener el usuario de la base de datos que tenga el correo electrónico proporcionado y estado 1
    $stmt = $con->prepare("SELECT * FROM usuarios WHERE email = :email AND estado = 1");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        
        $_SESSION['autentificado'] = "OK";
        $_SESSION['usuario'] = $email;

        
        header("Location: index.php"); 
        exit();
    } else {
        $error_message = "Credenciales incorrectas o usuario no habilitado. Por favor, inténtelo de nuevo.";
    }

    return $error_message;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $error_message = autenticarUsuario($con, $email, $password);

    // Si hay un mensaje de error, mostrarlo en la página de inicio de sesión
    if (!empty($error_message)) {
        echo '<div class="error">' . $error_message . '</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="css/loginStyles.css">
</head>
<body>
    <div class="login-container">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"> 
            <h2>Iniciar Sesión</h2>
            <div class="input-group">
                <label>Email:</label>
                <input type="text" name="email" required>
            </div>
            <div class="input-group">
                <label>Contraseña:</label>
                <input type="password" name="password" required>
            </div>
            <div class="input-group">
                <button type="submit">Ingresar</button>
            </div>
            <p>¿No tienes una cuenta? <a href="clienteNuevoFormulario.php">Regístrate</a></p>
            <p><a href="contraseñaRecuperar.php">¿Has olvidado tu contraseña?</a></p>
        </form>
    </div>
</body>
</html>
