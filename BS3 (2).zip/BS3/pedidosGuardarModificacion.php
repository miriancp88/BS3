<?php
include("conectar.php");
include("seguridad.php");
?>
<?php
// Incluye el archivo de conexión a la base de datos
include("conectar.php");

// Función para actualizar el estado del pedido
function actualizarEstadoPedido($con, $idPedido, $estadoPedido, $estado) {
    try {
        // Preparar la consulta SQL para actualizar el estado del pedido
        $sql = "UPDATE pedidos SET estadoPedido=:estadoPedido, estado=:estado WHERE idPedido=:idPedido";
        $statement = $con->prepare($sql);

        // Ejecutar la consulta SQL
        $statement->execute(array(':estadoPedido' => $estadoPedido, ':estado' => $estado, ':idPedido' => $idPedido));

        // Retorna true si la consulta se ejecutó con éxito
        return true;
    } catch (PDOException $e) {
        // Manejo de errores
        echo "Error: " . $e->getMessage();
        return false;
    }
}

// Verifica si se envió una solicitud POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupera los datos del formulario
    $idPedido = $_POST['idPedido'];
    $estadoPedido = $_POST['estadoPedido'];
    $estado = $_POST['estado'];

    // Llama a la función para actualizar el estado del pedido
    if (actualizarEstadoPedido($con, $idPedido, $estadoPedido, $estado)) {
        // Redirecciona a la página clientePedidos.php
        header("Location: panelAdministrador.php");
        exit();
    } else {
        // Si hay un error, muestra un mensaje de error
        echo "Ha ocurrido un error al intentar guardar los cambios.";
    }
} else {
    // Si no se recibió una solicitud POST, muestra un mensaje de error
    echo "No se han recibido datos del formulario.";
}
?>
