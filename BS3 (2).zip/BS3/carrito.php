<?php include 'header.php'; ?>

<?php
session_start();

// Incluye archivos necesarios
include 'conectar.php';


// Verifica si se ha enviado el código del artículo para agregar o disminuir del carrito
if (isset($_POST['codigoArticulo'])) {
    $codigoArticulo = $_POST['codigoArticulo'];
    agregarAlCarrito($codigoArticulo, $con);
} elseif (isset($_POST['disminuirCodigoArticulo'])) {
    $codigoArticulo = $_POST['disminuirCodigoArticulo'];
    disminuirEnCarrito($codigoArticulo, $con);
}

// Función para agregar un artículo al carrito
function agregarAlCarrito($codigoArticulo, $con) {
    // Consulta para obtener los detalles del artículo
    $query = "SELECT codigoArticulo, imagen, nombre, precio, descuento FROM articulos WHERE codigoArticulo = :codigoArticulo";
    $stmt = $con->prepare($query);
    $stmt->bindParam(':codigoArticulo', $codigoArticulo);
    $stmt->execute();
    $articulo = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verifica si se encontró el artículo
    if ($articulo) {
        // Verifica si el artículo ya existe en el carrito
        if (isset($_SESSION['carrito'])) {
            foreach ($_SESSION['carrito'] as &$item) {
                if ($item['codigoArticulo'] === $codigoArticulo) {
                    // Si el artículo ya existe, aumenta la cantidad y termina la función
                    $item['cantidad'] += 1;
                    return;
                }
            }
        }
        
        // Si el artículo no existe en el carrito, agrégalo con cantidad 1
        $articulo['cantidad'] = 1;
        $_SESSION['carrito'][] = $articulo;
    } else {
        echo "No se encontró el artículo.";
    }
}

// Función para disminuir en 1 la cantidad de un artículo en el carrito
function disminuirEnCarrito($codigoArticulo, $con) {
    // Verifica si el carrito está seteado en la sesión
    if (isset($_SESSION['carrito'])) {
        // Itera sobre los artículos en el carrito
        foreach ($_SESSION['carrito'] as &$item) {
            // Verifica si el artículo actual es el que estamos buscando
            if ($item['codigoArticulo'] === $codigoArticulo) {
                // Si la cantidad actual es mayor que 1, disminuye la cantidad en 1
                if ($item['cantidad'] > 1) {
                    $item['cantidad'] -= 1;
                } else {
                    // Si la cantidad es 1, elimina el artículo del carrito
                    unset($item);
                }
                return;
            }
        }
    }
    // Si no se encontró el artículo en el carrito, muestra un mensaje
    echo "No se encontró el artículo en el carrito.";
}

// Verifica si hay artículos en el carrito
if (isset($_SESSION['carrito']) && !empty($_SESSION['carrito'])) {
    $carrito = $_SESSION['carrito'];
    // Calcula el total del carrito
    $totalCarrito = calcularTotalCarrito($carrito);

    // Muestra todos los artículos en el carrito
    mostrarArticulosEnCarrito($carrito, $totalCarrito);
} else {
    // No hay artículos en el carrito
    echo "<p>No hay artículos en el carrito.</p>";
    echo '<a href="index.php">Seguir comprando</a>';
}

// Función para calcular el total del carrito
function calcularTotalCarrito($carrito) {
    $totalCarrito = 0;
    foreach ($carrito as $item) {
        $descuento = $item['descuento'];
        $totalArticulo = $item['precio'] - $descuento;
        $totalCarrito += $totalArticulo * $item['cantidad'];
    }
    // Guarda el total del carrito en la sesión
    $_SESSION['totalCarrito'] = $totalCarrito;
    return $totalCarrito;
}

// Función para mostrar los artículos en el carrito
function mostrarArticulosEnCarrito($carrito, $totalCarrito) {
    ?>
    <h2>Artículos en el Carrito</h2>
    <table border="1">
        <tr>
            <th>Código</th>
            <th>Imagen</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Descuento</th>
            <th>Cantidad</th>
           
            <th>Total</th>
            <th>Eliminar</th>
        </tr>
        <?php foreach ($carrito as $key => $item) : ?>
            <tr>
                <td><?php echo $item['codigoArticulo']; ?></td>
                <td><img src="uploads/<?php echo $item['imagen']; ?>" alt="Imagen del artículo" style="width: 200px;"></td>
                <td><?php echo $item['nombre']; ?></td>
                <td><?php echo $item['precio']; ?>€</td>
                <td><?php echo $item['descuento']; ?>€</td>
                <td><?php echo $item['cantidad']; ?>                
                    <form action="carrito.php" method="post">
                        <input type="hidden" name="codigoArticulo" value="<?php echo $item['codigoArticulo']; ?>">
                        <button type="submit" class="add-to-cart-btn">+</button>
                    </form>
                
                
                    <form action="carrito.php" method="post">
                        <input type="hidden" name="disminuirCodigoArticulo" value="<?php echo $item['codigoArticulo']; ?>">
                        <button type="submit" class="remove-from-cart-btn">-</button>
                    </form>
                    </td>
                <td><?php echo ($item['precio'] - $item['descuento']) * $item['cantidad']; ?>€</td>
                <td><a href="carritoEliminarArticulo.php?index=<?php echo $key; ?>">Eliminar</a></td>
            </tr>
        <?php endforeach; ?>
        <tr>
            <td colspan="6">Total del carrito:</td>
            <td colspan="2"><?php echo $totalCarrito; ?>€</td>
        </tr>
    </table>
    <button onclick="window.location.href = 'index.php';">Seguir Comprando</button>
    <button onclick="window.location.href = 'carritoConfirmarPedido.php';">Confirmar pedido</button>
<?php
}

?>


