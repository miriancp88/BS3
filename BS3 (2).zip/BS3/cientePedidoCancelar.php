<?php
// Función para cancelar un pedido
function cancelarPedido($con) {
    // Verificar la sesión
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    // Verificar si el usuario está autenticado
    if (isset($_SESSION['autentificado']) && $_SESSION['autentificado'] == "OK") {
        // Verificar si se ha enviado una solicitud POST y si se recibió un ID de pedido válido
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['idPedido'])) {
            // Obtener el ID del pedido enviado por el formulario
            $idPedido = $_POST['idPedido'];

            try {
                // Actualizar el estado del pedido a cancelado en la base de datos
                $query = "UPDATE pedidos SET estado = 0, estadoPedido = 'cancelado' WHERE idPedido = :idPedido";
                $statement = $con->prepare($query);
                $statement->bindParam(':idPedido', $idPedido, PDO::PARAM_INT);
                $statement->execute();

                // Redirigir de nuevo a la página de pedidos del usuario
                header("Location: clientePedidos.php");
                exit;
            } catch (PDOException $e) {
                echo 'Error: ' . $e->getMessage();
            }
        } else {
            // Si no se recibió un ID de pedido válido, redirigir al usuario a la página de pedidos del usuario
            header("Location: clientePedidos.php");
            exit;
        }
    } else {
        // Si el usuario no está autenticado, redirigirlo a la página de inicio de sesión
        header("Location: login.php");
        exit;
    }
}


include_once "conectar.php";
include_once "seguridad.php";

// Llamar a la función para cancelar el pedido
cancelarPedido($con);
?>
