<?php
include("conectar.php");

include("seguridad.php");


// Función para obtener pedidos según los parámetros de búsqueda y ordenamiento
function obtenerPedidos($con, $buscar = null, $ordenar = null) {
    try {
        $query = "SELECT idPedido, fecha, total, estadoPedido, codUsuario, estado FROM pedidos";

        // Verificar si se ha enviado un código de usuario para buscar
        if (!empty($buscar)) {
            $codUsuario = "%$buscar%";
            $query .= " WHERE codUsuario LIKE :codUsuario";
        }

        // Verificar si se ha enviado un parámetro para ordenar
        if (!empty($ordenar)) {
            $query .= " ORDER BY $ordenar";
        }

        $statement = $con->prepare($query);

        // Vincular valores si es necesario
        if (!empty($codUsuario)) {
            $statement->bindParam(':codUsuario', $codUsuario, PDO::PARAM_STR);
        }

        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
        return array(); // Devolver un array vacío en caso de error
    }
}

// Función para generar la tabla HTML de pedidos
function generarTablaPedidos($pedidos) {
    ?>
    <table>
        <thead>
            <tr>
                <th>ID Pedido</th>
                <th>Fecha</th>
                <th>Total</th>
                <th>Estado del Pedido</th>
                <th>Código de Usuario</th>
                <th>Estado</th>
                <th>Modificar</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($pedidos as $pedido): ?>
            <tr>
                <td><?php echo $pedido['idPedido']; ?></td>
                <td><?php echo $pedido['fecha']; ?></td>
                <td><?php echo $pedido['total']; ?></td>
                <td><?php echo $pedido['estadoPedido']; ?></td>
                <td><?php echo $pedido['codUsuario']; ?></td>
                <td><?php echo $pedido['estado']; ?></td>
                <td>
                    <a href="pedidosModificarFormulario.php?idPedido=<?php echo $pedido['idPedido']; ?>&estadoPedido=<?php echo $pedido['estadoPedido']; ?>&estado=<?php echo $pedido['estado']; ?>" class="btn">Modificar</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php
}

// Obtener pedidos según los parámetros de búsqueda y ordenamiento
$buscar = isset($_GET['buscar']) ? $_GET['buscar'] : null;
$ordenar = isset($_GET['ordenar']) ? $_GET['ordenar'] : null;
$pedidos = obtenerPedidos($con, $buscar, $ordenar);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de Pedidos</title>
    <link rel="stylesheet" href="css/tablaUsuarios.css"> <!-- Enlace al archivo CSS -->
</head>
<body>

<h2>Tabla de Pedidos</h2>

<div class="table-container">
    <a href="pedidosNuevoFormulario.php" class="btn">Agregar Nuevo Pedido</a> <!-- Enlace para agregar nuevo pedido -->
</div>

<form action="pedidos.php" method="GET">
    <div class="search-container">
        <input type="text" name="buscar" placeholder="Buscar por código de usuario">
        <button type="submit" class="btn">Buscar</button>
    </div>
    <br>
    <div class="order-container">
        <label for="ordenar">Ordenar por:</label>
        <select name="ordenar" id="ordenar">
            <option value="fecha">Fecha</option>
            <option value="estadoPedido">Estado del Pedido</option>
        </select>
        <button type="submit" class="btn">Ordenar</button>
    </div>
</form>

<div class="table-container">
    <?php generarTablaPedidos($pedidos); ?>
</div>

<button onclick="window.location.href='panelAdministrador.php'" class="btn">Volver</button>

</body>
</html>
