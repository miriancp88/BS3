<?php
include("conectar.php");
include("seguridad.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Estado del Pedido</title>
    <link rel="stylesheet" href="css/modificarUsuarioFormulario.css"> 
</head>
<body>

<div class="container">
    <h2>Modificar Estado del Pedido</h2>
    <form action="pedidosGuardarModificacion.php" method="POST">
        <div class="form-group">
            <label for="idPedido">ID del Pedido:</label>
            <input type="text" id="idPedido" name="idPedido" placeholder="ID del pedido" value="<?php echo isset($_GET['idPedido']) ? $_GET['idPedido'] : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="estadoPedido">Nuevo Estado del Pedido:</label>
            <select id="estadoPedido" name="estadoPedido" required>
                <option value="pagado" <?php echo ($_GET['estadoPedido'] == 'pagado') ? 'selected' : ''; ?>>Pagado</option>
                <option value="pendiente" <?php echo ($_GET['estadoPedido'] == 'pendiente') ? 'selected' : ''; ?>>Pendiente</option>
                <option value="cancelado" <?php echo ($_GET['estadoPedido'] == 'cancelado') ? 'selected' : ''; ?>>Cancelado</option>
                <option value="enviado" <?php echo ($_GET['estadoPedido'] == 'enviado') ? 'selected' : ''; ?>>Enviado</option>
            </select>
        </div>
        <div class="form-group">
            <label for="estado">Nuevo Estado del Pedido:</label>
            <select id="estado" name="estado" required>
                <option value="1" <?php echo ($_GET['estado'] == '1') ? 'selected' : ''; ?>>Activo</option>
                <option value="0" <?php echo ($_GET['estado'] == '0') ? 'selected' : ''; ?>>Inactivo</option>
            </select>
        </div>
        <button type="submit" class="btn">Guardar Cambios</button>
        <button onclick="window.location.href='clientePedidos.php'" class="btn">Volver</button>
    </form>
</div>

</body>
</html>
