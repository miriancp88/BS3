<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BS3</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

<aside class="right-sidebar">
    <nav>
        <ul>
            <?php if(isset($_SESSION['autentificado']) && $_SESSION['autentificado'] == "OK") { ?>
                <?php if ($rolUsuario == "cliente") { ?>
                    <!-- Mostrar menú para clientes -->
                    <li><a href="clientePerfil.php">PERFIL</a></li><br>
                    <li><a href="clientePedidos.php">PEDIDOS</a></li><br>
                <?php } elseif ($rolUsuario == "administrador" || $rolUsuario == "empleado") { ?>
                    <!-- Mostrar botón para panel de administrador -->
                    <li><a href="panelAdministrador.php"><button>Panel Administrador</button></a></li>
                <?php } ?>
            <?php } else { ?>
               
            <?php } ?>
        </ul>
    </nav>
</aside>

</body>
</html>



